# Configuring new projects manually



Add include directories  

![Include](./images/vs-include.png)  


Add linker directories  

![Linker](./images/vs-linker.png)


Add linker additional dependencies  

![Additional dependencies](./images/vs-linker-dep.png)